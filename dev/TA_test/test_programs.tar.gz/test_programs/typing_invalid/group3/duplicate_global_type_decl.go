package a

type a int
type a int

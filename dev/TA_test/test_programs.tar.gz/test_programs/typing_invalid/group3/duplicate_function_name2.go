package a

func f(){
}

func f(a int, b string) float64 {
}

package main

func main() {
	var a float64 = 6.89
	var output int = a
	println(output)
}

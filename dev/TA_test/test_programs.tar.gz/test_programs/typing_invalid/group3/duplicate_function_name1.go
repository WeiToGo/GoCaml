package a

func f(){
}

func f(){
}

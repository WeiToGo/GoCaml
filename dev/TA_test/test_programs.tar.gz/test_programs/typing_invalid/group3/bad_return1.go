package main

func add(a int, b int) int {
	var result int = a + b

	// Invalid since there is no return while the function should return an int
}

func main() {
		// Invalid since the - operator expects a numeric type
    println(-false)
}

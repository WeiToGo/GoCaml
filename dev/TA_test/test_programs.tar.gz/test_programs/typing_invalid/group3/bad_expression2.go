package main

func main() {
		// Invalid since the ! operator expects a boolean
    println(!"true")
}

package main

func main() {
		// Invalid since the - operator expects a numeric type
    println(-false)
}

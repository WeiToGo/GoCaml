package main

func main() {
    // Invalid because the left and right operands are of different types
    println("go" + "lang" + 1)
}

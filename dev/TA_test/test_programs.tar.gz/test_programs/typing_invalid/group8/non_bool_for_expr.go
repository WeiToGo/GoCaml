package main

func main() {
	for i := 0; i; i++ {
		print("Blah!");
	} 
}

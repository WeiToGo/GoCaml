package main;

func main() {
	print("Hello!");
}

func function() {
	print("Function declaration one.");
}

func function() {
	print("Function declaration two.");
}

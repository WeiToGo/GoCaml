package main

func main() {
	var z int;
	x, y, z := 1, 2, "test";
	print(x,y,z);
} 

package main

func main() {
	var i num = 5;
	if(i < 10) {
		print("Ghosts!");
	} 
} 

package main

func main() {
	var i int = 5;
	if(i) {
		print("Ghosts!");
	} 
} 

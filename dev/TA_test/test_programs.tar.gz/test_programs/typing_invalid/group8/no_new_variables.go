package main

func main() {
	var z int;
	var x int;
	var y int;
	x, y, z := 1, 2, 3.0;
	print(x,y,z);
} 

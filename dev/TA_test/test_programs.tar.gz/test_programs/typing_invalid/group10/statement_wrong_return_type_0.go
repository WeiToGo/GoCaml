package main;

func f() int{
    x := 5.0
    return x
}

func main() {
    var x int
    x = f()

}

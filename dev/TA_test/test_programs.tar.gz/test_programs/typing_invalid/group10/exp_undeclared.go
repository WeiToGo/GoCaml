package main;

func f (){
	return
}

func main() {
    var y,z int
    a = 3
}

package main;

func f (x,y int){
	return
}

type str struct {
	x,y int
}

func main() {
	var v str
	var a float64
	a = v.y
	println(a)
}

package main;

func main() {
	var x float64
	var x int
}

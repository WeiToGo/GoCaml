package main;

func f (x,y int){
	return
}

type str struct {
	x,y int
}

func main() {
	var x []string
	x = append(y,"hi")
	x = append(x,"bye")
	println(x[0])
}

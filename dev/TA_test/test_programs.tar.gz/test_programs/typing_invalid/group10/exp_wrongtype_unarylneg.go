package main;

func f (){
	return
}

func main() {
	y := 3
    a := !y
    println(a)
}

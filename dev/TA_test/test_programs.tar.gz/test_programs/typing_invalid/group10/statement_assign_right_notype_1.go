package main;

func f (){
	return
}

func main() {
    var y,z int
    y,z = 1,1+1.2
    println(y,z)
}

package main;

func f (){
	return
}

func main() {
    var x,y,z int

    y,z = 1,f
}

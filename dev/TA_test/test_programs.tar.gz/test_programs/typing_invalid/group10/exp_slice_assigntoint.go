package main;

func f (x,y int){
	return
}

type str struct {
	x,y int
}

func main() {
	var x []string
	var y int
	
	x = append(x,"hi")
	y = append(x,"bye")
	println(x[0])
}

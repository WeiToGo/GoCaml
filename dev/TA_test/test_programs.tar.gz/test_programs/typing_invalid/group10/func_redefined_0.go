package main;

func f(){

}

func f(){

}
func main() {
    var x int
    x++
}

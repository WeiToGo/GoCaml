package main;

func main() {
	var x point
}


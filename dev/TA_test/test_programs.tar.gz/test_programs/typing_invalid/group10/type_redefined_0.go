package main;

func main() {
	type num int
	type num float64
}



package main;

func f (){
	return
}

func main() {
	y := "hi"
    a := -y
    println(a)
}

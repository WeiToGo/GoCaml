package main;

func f (x,y int){
	return
}

func main() {
	y := "hi"
	f(3,"hi")
    a := y
    println(a)
}

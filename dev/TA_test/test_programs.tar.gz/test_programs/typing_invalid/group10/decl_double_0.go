package main;

func main() {
	var x,x int
}

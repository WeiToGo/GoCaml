package main;

func f() {
    x := 5.0
    return x
}

func main() {
    var x int
    
    x++
}

package main;

func f (x,y int){
	return
}

type str struct {
	x,y int
}

func main() {
	type t1 int
	var variable t1
	println(variable)


	var v str
	v.x = 3
	println(v)
}

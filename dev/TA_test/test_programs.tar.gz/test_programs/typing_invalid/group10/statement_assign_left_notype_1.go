package main;

func f (){
    return
}

func main() {
    var x,y,z int

    f,z = 1,2
}

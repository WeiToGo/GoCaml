package main;

func main() {
    var x,y,z int
    x,y,z := 1,2,3

    x= y + z
}

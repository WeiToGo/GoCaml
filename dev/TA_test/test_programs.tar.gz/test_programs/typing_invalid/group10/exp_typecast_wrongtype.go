package main;

func f (x,y int){
	return
}

type str struct {
	x,y int
}

func main() {
	var x float64
	var y str
	y = str(x)
	println(y)
}

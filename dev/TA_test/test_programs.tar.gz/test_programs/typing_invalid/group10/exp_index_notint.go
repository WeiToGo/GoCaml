package main;

func f (x,y int){
	return
}

func main() {
	var y [3]int
	y[0] = 1
	y[1] = 2
	y[2] = 3
    a := y[1.1]
    println(a)
}

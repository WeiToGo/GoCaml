package main;

func main() {
    var x,y,z int
    a,y,z := 1,2,"string"

}

package main;

func f(x,x int){

}

func main() {
    var x int
    x++
}

package main


func main() {
	type v int
	{
		var x v = v(0)
		var v v = v(1)
		var u v = v(2)
		println(x,v,u)
	}
}

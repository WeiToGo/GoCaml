package main;

func f (x,y int){
	return
}

func main() {
	y := 'c'
    a := y[1]
    println(a)
}

package main;

func f(x,y int){
	y := "string"
}

func main() {
    var x int
    x++
}

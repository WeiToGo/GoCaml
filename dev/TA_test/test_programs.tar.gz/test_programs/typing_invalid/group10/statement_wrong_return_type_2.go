package main;

func f() float64 {
    x := 5.0
    return 
}

func main() {
    var x int
    
    x++
}

package main

var a = +("string")

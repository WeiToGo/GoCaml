package main

var y int = 1
func switch_stmts() {

	switch (3+0.5); y {
	case 0: "zero"
	default: "valid"
	case 1, 3, 5: "odd"
	}
}

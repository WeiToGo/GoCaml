package main

var y int = 1
func switch_stmts() {
	switch z:=0; {
	case 0: "zero"
	case 1: "odd" 
	}
}

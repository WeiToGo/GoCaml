package main

func printing(){
	println(9%4.6)
}

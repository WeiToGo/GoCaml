package main 

func f() {
	var a = "str" + 3.4
	a &= 1
}

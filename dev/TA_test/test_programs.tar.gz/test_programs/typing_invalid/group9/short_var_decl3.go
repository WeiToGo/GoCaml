package main 

func short_decl() {
	a := 5.5 
	x := "hello"
	a, b := 0, 1 //a was assigned float
}

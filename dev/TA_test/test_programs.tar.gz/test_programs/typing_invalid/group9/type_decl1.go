package main

type num int
var e num = 4  

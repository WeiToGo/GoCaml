package main 

func f() {
	var _ int 
	_ <<= 1
}

package main

var x = `srtb` - 5

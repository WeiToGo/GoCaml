package main 

func f() {
	var a string = "hello"
	print(a[0])
}

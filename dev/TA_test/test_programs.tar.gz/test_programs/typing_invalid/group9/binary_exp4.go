package main

var a = ("string" != 5)

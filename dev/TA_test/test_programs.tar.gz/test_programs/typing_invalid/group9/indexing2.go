package main 

func f() {
	var a [1]string
	print(a[0.5])
}

package main 

func f() {
	var a = 'r'-4.5
	a += 1
}

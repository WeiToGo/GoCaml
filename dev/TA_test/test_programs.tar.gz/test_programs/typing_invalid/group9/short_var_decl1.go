package main

func short_decl() {
	a ,b, c := 5, 10+34.5, 'r'
}

package main

var x = 0
var a = !(x)

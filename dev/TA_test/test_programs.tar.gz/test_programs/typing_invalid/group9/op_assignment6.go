package main 

func f() {
	var a, b = 'e', 1
	a &^= b
}

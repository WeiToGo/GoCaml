package main

var a float64 = "string"

package main

var x struct {
	a, b int
}
var a = -(x)

package main 

func f(){
	var s int = 0
	append(s, "str")
}

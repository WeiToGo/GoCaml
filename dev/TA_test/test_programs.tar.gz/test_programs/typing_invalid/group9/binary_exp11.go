package main

var a =  45 * 'r'

package main

var a = true < 5

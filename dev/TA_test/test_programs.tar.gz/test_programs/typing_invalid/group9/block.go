package main 

func f() {
	var a = "str"
	{
		print(34-a)
	}
}

package main

func if_stmts() {
	var x string
	if x = 0; x == 0 {
		return
	}
}

package main

func for_stmts() { 
	for ; ; 10.4++ {
		return
	}
}

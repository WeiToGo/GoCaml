package main

type x string
var (
	x, y int
)

package main

var a = 'r' == 5

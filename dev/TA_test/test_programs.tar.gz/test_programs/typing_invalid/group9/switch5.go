package main

var x, y int = 1
func switch_stmts() {
	switch z:=0; (x+z){
	case y < 0: "str1"
	case y > 1: "str2"
	default: "str"
	}

}

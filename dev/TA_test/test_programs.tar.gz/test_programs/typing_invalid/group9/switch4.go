package main

var y int = 1
func switch_stmts() {
	switch z:=0; {
	case y < 0.5: "str1"
	case y > 1.6: "str2"
	default: "str"
	}
}

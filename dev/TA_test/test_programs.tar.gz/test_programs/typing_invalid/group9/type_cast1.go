package main 

func f() {
	var a = 6
	string(a)

}

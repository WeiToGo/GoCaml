package main 

func f() {
	var a struct {
		x, y int
	}
	print(rune(a))
}

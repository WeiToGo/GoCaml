package main

var a = 45 >= 4.6

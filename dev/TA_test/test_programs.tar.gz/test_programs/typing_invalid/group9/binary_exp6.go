package main

var a = "string" <= 4.6

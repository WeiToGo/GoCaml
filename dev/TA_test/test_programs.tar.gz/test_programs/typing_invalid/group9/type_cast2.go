package main 

func f() {
	print(int(45 -"string"))
}

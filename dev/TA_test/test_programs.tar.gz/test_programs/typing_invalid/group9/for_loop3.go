package main

func for_stmts() { 
	for 34.5 + 'a'; a < 10; {
		return
	}
}

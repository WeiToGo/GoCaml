package main

func assign_stmts() {
	var a,b int;
	a, b = 0, 1.5

}

package main

var x, y int 
var (
	x float64
)

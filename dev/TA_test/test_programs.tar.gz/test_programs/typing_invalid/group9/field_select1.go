package main 

func f() {
	var a = 10
	print(a.x)
}

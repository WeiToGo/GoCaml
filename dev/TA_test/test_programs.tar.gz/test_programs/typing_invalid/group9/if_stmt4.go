package main

func if_stmts() {
	var y int
	if false {
		print((4+3)/2)
	} else if y {
		return
	} else {
		return
	}
}

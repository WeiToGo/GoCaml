package main

var a  = 34 & 'r'

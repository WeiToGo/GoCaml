package main

var a = true || "string"

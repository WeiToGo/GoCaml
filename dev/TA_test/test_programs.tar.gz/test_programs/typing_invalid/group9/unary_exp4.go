package main

var a = ^("ewr")

package main

var x1, x2 rune = `str`, '1'

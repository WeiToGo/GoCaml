package main 

func f() {
	var a = 3.5
	var b = 9
	b /= a
}

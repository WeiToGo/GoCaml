package main

func f4(a int) {
	a = (3.4/4)
}

package main

func f3() int {
	return 
}

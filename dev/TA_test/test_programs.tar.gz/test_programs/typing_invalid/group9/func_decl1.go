package main

func f0(){
	return(3)
}

package main
package main

var y int = 1
func switch_stmts() {
	switch y+"str" {
	case 0: "zero"
	case 1, 3: "odd" 
	}
}

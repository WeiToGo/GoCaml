package main

var a = 45.6 | 45

package main

func foo()rune {
	return ("str"%4.5)
}

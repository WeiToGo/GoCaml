package main 

func f(){
	var s []float64
	append(s, "str")
}

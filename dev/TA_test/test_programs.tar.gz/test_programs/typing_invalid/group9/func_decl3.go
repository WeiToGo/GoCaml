package main

func f2(a int, b int) {
	var b string
}

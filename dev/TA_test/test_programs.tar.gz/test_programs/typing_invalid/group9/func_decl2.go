package main

func f1(a int, a string) {
	return
}

package main

func if_stmts() {
	var x = 0
	if false {
		return
	} else if x = x; false {
		print(x)
	} else {
		print(x-'r')
	}
}

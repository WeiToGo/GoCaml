package main

var a = (23 > false)

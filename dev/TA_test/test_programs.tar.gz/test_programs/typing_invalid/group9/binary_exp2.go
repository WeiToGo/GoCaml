package main

var a = 'r' && false

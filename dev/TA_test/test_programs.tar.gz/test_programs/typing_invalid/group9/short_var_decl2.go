package main

func short_decl() {
	a ,b := 5, 10
	x := "hello"
	a, b := 0, 1
}

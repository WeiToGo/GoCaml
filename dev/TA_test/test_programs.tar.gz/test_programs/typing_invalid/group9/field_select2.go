package main 

func f() {
	var k int 
	var a struct {
		x, y float64
		z string
	}
	k.x
}

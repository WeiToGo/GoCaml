package main

func printing(){
	println(6, 3+'e', 7.5)
}

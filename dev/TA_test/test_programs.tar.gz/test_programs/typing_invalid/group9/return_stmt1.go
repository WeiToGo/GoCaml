package main

func f()[4]int {
	var x [4]rune 
	return x
}

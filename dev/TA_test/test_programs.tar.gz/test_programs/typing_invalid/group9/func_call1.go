package main

func f5(a int, b int) {}

func main(){
	f5(5.4, 3) 
}

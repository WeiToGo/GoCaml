/* Trying to append a float to an int slice */

package main

func main() {
     var x []int 
     x = append(x,1.0)
     return   
}

/* In this file, none of the variables on the left hand side have been declared */
package main

func main () {
	var v1, v2, v3 int
	v1, v2, v3 := 1, 2, 3
	return
}

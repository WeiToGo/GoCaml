/* Trying to use undeclared type t */

package main

func main() {
     var x t
     return
}

/* This program is has an incorrectly typed condition in an if statement */

package main

func main() {
	var x [5]int
	if x {
		return
	}
}

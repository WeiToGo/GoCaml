/* trying to access non-integer position of array */

package main

func index(x [32]int) int {
     return x[false]
}

func main() {
     return
}

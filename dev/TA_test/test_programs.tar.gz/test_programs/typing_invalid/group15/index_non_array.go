/* trying to access index of non-array */

package main

func main() {
     2[2]
     return
}

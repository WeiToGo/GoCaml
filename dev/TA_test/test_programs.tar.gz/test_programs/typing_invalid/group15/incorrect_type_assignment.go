/* In this program, we assign a float to an integer variable, without first casting it */

package main

func main() {
   var x, y, z int
   x = 3.
   y = 4
   z = 5.
   return
}

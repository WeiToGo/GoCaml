/* This program is tries to select from an expression not of type struct */

package main

func main() {
	var x int
	x.z = 4
}

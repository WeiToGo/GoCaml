/* We are only passing one argument to times, while it is expecting two */

package main

func times(n int, m int) int {
   return n * m
}

func main() {
     times(1)
     return   
}

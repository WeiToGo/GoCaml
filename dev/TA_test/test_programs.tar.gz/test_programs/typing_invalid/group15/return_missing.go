/* This program is missing a return statement in one of the branches of fact */

package main

func fact(n int) int {
   if n == 0 {
      return 1
   } else {

   }
}

func main() {
return   
}

/* We are trying to apply 2 to something which is not a function */

package main

func main() {
     var x int = 3
     x(2)
     return   
}

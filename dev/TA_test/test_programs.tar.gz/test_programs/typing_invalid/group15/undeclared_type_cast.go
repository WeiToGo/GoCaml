/* Trying to cast 3 to undeclared type t */

package main

func main() {
     t(3)
     return
}

/* We have a switch over some int, but the cases are over bools */

package main

func main() {
     switch 2 {
     	    case true:
	    default:
     }
     return   
}

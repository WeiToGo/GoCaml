/* Trying to use undeclared var */

package main

func main() {
     a + 3
     return
}

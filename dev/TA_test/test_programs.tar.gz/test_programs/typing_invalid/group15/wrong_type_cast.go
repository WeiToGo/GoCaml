/* Trying to cast 3 to undeclared type t */

package main

func main() {
     type t []int
     t(3)
     return
}

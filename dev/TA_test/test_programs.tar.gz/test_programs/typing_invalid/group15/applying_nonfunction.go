/* In this file, we attempt to apply a non-function */
package main

func main () {
	var x bool = true
	x(3);
}

/* uminus expects integer but was given boolean */

package main

func main() {
     -true
     return
}

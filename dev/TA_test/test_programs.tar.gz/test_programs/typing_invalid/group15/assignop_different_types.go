/* assign operation += needs to expressions of the same type, but x is int and 2.0 is float */

package main

func main() {
     var x int
     x += 2.0
     return
}

/* Trying to append to a non-slice */

package main

func main() {
   var x int
   x = append(x, 1)
   return 
}

// if expression must have type bool

package main

func main() {
	x := "true"
	if y:=true; x {
		print(x, y)
	}
}

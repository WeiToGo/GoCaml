// illegal print operand

package main

func main() {
	var arr [5]int
	print(arr)
}

// arithmetic negation can only be applied to int/float64/rune 

package main

func main() {
	x := "x"
	print(-x)
}

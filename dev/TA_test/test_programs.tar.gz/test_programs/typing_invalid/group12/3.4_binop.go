// in arg1 || arg2, arg1 and arg2 must both be bool

package main

func main() {
	x, y := 1, 2
	if x==y+1 || y {
		print(x)
	}
}

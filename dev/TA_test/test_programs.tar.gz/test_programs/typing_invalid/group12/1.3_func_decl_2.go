// function f has two parameters with the same name

package main

func f(x int, x int) {

}

func main() {
	f(3, 3)
}

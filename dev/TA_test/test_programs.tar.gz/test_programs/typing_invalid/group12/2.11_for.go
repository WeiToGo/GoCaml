// for expression must have type bool

package main

func main() {
	x, y := 1, 0
	for i := 0; x-y; i++  {
		println()
	}
}

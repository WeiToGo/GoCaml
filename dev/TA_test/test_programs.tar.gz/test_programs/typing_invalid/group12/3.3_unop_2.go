// logical negation can only be applied to bool

package main

func main() {
	x := 0
	print(!x)
}

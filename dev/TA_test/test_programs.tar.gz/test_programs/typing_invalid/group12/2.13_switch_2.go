// y does not have type bool

package main

func main() {
	var x, y int
	switch {
	case x<y, y:
		print()
	}
}

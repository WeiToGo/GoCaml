// x undeclared

package main

func main() {
	print(x)
}

// bitwise negation can only be applied to int/rune

package main

func main() {
	x := 3.01
	print(^x)
}

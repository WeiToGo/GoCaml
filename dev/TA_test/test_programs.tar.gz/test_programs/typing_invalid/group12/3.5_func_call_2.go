// mismatch in argument types

package main

func f (x, y int) {
	
}

func main() {
	f(2, true)
}

// cannot apply append to array a

package main

func main() {
	var a [2]int
	a = append(a, 1)
}

// x repeated on left side of :=

package main

func main() {
	x, x:=1,2
	print(x)
}

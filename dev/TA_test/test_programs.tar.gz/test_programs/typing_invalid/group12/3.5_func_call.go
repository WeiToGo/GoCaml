// f expects 2 arguments

package main

func f (x, y int) {
	
}

func main() {
	f(2)
}

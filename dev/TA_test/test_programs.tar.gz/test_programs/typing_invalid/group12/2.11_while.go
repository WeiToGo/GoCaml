// while expression must have type bool

package main

func main() {
	x := 2
	for x {
		x--
	}
}

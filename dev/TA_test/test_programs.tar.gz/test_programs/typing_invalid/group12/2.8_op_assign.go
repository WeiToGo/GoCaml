// mismatched types string and int

package main

func main() {
	w := "s"
	w += 1
	print(w)
}

// mismatched types rune and string

package main


func main() {
	x,y := 'x',"x"
	print(x%y)
}


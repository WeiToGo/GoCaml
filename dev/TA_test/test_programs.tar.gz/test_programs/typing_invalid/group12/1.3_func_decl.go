// f already declared in current scope

package main

var f int

func f() {

}

func main() {
	print(f)
}

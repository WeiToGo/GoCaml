// a does not have a struct type

package main

func main() {
	var a [3]int
	x := 0
	print(a.x)
}

package a

func a() {

}

func main() {
	var b = a(); //Assigning void to a variable
}

package main

func something(something int) {
	var something int
}

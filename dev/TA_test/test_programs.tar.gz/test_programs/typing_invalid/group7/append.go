package main

func main() {
	var a [10]int;
	append(a, 5);
}

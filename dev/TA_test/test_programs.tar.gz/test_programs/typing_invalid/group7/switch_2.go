package main

func main() {
	
	switch {
	case 5: //should be bool if expression in switch statement is missing
		print("works");
	default:
		print("default");
	}
}

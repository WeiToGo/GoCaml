package a

func main() int {
	if true {
		return 1
	} else if false {
		return 0
	} else {
		return 1.0
	}
}

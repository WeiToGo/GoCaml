package main

func main() {
	type c struct { x int; };
	var a c;
	var b int;
	random := b.x
}

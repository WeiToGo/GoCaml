package main

func test() bool {
	x := 3;
	switch x {
	case 3:
		return false;
	}
}

func main() {
	test();
}

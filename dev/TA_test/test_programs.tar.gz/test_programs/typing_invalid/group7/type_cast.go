package main


func main() {
	var a int;
	a = int("test");
}

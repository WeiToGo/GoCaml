package main

func main() {
	var test bool;
	var b int = 5;
	
	test = !b;
}

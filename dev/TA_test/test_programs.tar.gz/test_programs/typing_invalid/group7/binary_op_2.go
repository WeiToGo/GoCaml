package a

func main() {
	var a = "string"
	var b = a << "a" //Incompatible operator type
}

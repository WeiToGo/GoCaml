package main

func main() {
	type c struct { x int; };
	var a c;
	println(a);
}

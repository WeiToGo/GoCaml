package a

func a() {

}

func main() {
	//Printing void
	print(a());
}

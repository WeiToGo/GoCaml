//ERROR: LHS has no new variable but has blank identifier "_"

package main;

func main(){
	var a,b,c int;
	a,b,c,_ := 1,2,3,4;

}

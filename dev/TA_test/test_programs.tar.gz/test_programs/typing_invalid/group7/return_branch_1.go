package main

func test() bool {
	x := 3;
	if x < 3 {
		return true;
	}
}

func main() {
	test();
}

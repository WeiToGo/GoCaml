package main

func main() {
	var a []float64
	
	append(a, 1) //ERROR: Should append a float64
}

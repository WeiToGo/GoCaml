package main

func main() {
	if 1 {
	}
}

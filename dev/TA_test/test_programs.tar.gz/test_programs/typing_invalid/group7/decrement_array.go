package main

func main() {
	var one [7]int;
	one[6] = 0;
	one--;
}

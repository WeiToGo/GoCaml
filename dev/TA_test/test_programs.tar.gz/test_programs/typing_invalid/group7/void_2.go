package a

func a() {

}

func main() {
	//Using void in a switch statement
	switch a() {
	default:
		print("Hi");
	}
}

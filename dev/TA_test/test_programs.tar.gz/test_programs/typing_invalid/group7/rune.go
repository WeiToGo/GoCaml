package main

func main() {
	var something rune = "something";
}

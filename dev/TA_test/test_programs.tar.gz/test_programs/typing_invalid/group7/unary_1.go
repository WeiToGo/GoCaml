package main

func main() {
	var test int;
	type a int;
	var b a;
	b = 10;
	
	test = -b;
}

package a

func main() {
	var a = 3;
	a = a * true; //Different types
}

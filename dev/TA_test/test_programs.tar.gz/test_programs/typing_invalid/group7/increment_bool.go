package main

func main() {
	var one bool = true;
	one++;
}

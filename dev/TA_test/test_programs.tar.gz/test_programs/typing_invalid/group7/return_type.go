package main

func test() int {
	return false;
}

func main() {
	test();
}

package main

func main() {
	var something int = 7.0;
}

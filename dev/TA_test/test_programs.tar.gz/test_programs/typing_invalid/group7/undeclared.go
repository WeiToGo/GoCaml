package a

func main() {
	var a = 3 * int(a); //Use of undeclared variable
}

package main

var x float64

// x is not an int expression
var y int = x

package main

func main() {
	var x int
	var y float64

	x += y
}

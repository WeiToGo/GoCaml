package main

func main() {
	for true {
		var x int
	}
	println(x)
}

package main

// 3.4 is not an int expression
var x int = 3.4

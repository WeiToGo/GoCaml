package main

func main() {
	var p struct {
		x, y, z float64
	}
	p++
}

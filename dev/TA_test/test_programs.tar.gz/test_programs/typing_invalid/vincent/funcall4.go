package main

func f(x, y int) {
}

func main() {
	// Too many arguments
	f(3, 4, 5)
}

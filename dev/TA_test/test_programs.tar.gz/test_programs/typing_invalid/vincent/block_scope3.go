package main

func main() {
	if true {
	} else {
		var x int
	}
	println(x)
}

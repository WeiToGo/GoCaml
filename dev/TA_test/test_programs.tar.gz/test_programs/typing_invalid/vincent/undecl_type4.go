package main

// Nested undeclared type
type s struct {
	x, y [][][3]t
}

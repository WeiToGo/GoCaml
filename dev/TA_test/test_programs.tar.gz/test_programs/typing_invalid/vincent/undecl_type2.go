package main

type p struct {
	// t is undeclared
	x, y t
}

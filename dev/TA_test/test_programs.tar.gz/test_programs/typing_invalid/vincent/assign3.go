package main

func main() {
	type t float64
	var w t
	var x float64 = w
}

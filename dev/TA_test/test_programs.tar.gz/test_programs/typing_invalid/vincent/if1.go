package main

func main() {
	// Condition to an if must be a bool (or alias to bool)
	if 42 {
	}
}

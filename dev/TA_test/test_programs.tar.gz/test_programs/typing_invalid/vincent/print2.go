package main

func main() {
	var p []int
	println(p)
}

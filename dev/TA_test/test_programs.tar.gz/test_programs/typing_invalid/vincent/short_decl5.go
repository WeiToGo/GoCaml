package main

func main() {
	a, a := 1, 2
	println(a)
}

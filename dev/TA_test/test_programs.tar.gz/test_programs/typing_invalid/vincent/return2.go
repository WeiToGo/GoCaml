package main

func an_int() int {
	// Return expression is not an int
	return "hello"
}

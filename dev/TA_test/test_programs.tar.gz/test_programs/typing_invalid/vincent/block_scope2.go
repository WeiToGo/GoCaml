package main

func main() {
	if true {
		var x int
	}
	println(x)
}

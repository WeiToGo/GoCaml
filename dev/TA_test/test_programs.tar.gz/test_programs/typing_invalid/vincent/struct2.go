package main

func main() {
	type t struct {
		a int
		_ int
		c int
	}
}

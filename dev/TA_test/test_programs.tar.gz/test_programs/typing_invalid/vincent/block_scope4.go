package main

func main() {
	for {
		var x int
	}
	println(x)
}

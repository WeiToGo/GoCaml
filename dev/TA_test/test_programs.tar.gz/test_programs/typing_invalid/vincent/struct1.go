package main

func main() {
	type t struct {
		a int
		a int
	}
}

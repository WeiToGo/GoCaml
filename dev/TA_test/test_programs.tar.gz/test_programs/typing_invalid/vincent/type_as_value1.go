package main

type t int

func foo() {
	// Cannot use TyId as ExprId
	println(t)
}

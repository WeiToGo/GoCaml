package main

func f(x int) {
}

func main() {
	// Argument is not an int
	f(3.14)
}

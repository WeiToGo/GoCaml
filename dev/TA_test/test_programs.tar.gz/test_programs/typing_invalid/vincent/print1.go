package main

func main() {
	type point struct {
		x, y, z float64
	}
	var p point
	println(p)
}

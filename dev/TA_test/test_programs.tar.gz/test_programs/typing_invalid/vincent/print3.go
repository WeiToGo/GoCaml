package main

func main() {
	var p [5]int
	println(p)
}

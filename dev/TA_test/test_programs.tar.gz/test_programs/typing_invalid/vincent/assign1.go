package main

func main() {
	var x int = 1.0
}

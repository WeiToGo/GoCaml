package main

func f() {
}

func main() {
	a := f()
}

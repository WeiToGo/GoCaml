package main

func main() {
	for x := 0; x < 10; x++ {
		var y int
	}
	println(y)
}

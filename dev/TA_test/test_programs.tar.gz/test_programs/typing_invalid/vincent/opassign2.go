package main

func main() {
	var x rune
	var y int

	x <<= y
}

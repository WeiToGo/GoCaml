package main

func main() {
	// No new variable on lhs
	_ := 3
}

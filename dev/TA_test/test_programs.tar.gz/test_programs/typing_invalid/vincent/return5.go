package main

func test() {
	// Return should not have an expression in void function
	return 3
}

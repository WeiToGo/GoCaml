package main

type t struct {
	// No recursive types
	x, y t
}

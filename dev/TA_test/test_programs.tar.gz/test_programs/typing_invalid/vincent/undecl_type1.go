package main

// t is undeclared
var x t

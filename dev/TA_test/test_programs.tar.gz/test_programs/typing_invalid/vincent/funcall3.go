package main

func f(x, y int) {
}

func main() {
	// Too few arguments
	f(3)
}

package main

func main() {
	{
		var x int
	}
	println(x)
}

package main

// Cannot add int and float64
var x = 2 + 1.2

package main

func main() {
	var a, a = 10, 20
	println(a)
}

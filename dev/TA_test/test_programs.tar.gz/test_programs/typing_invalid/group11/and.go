package main

var x bool=(5&&3)

//this program corresponds...to second exit of symEXP in GoType.c

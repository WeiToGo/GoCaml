package main

var x int=2.0

//this invlaid program corresponds to checks for whether a variable is used type-correctly, such as in (GoType.c) symIDTYPEEXPLIST, symIDIDTYPEEXPLIST

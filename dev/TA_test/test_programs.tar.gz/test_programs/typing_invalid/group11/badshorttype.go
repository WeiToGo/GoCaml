package main

func main(){

var x int
x,y=5.0,5.0

}

//this program corresponds to the first check in symSHORTEXPLIST where we make sure any predefined variables in a short variable declaration have type matching their right-hand-side counterpart

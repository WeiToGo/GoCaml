package main

func main(){

for i:=0;3+5;i++{

}

}

//this invalid program corresponds to a check for whether the condition in a full for loop (init and post statements) is a bool, as in (GoType.c) symFORLOOP (third and fourth exits)

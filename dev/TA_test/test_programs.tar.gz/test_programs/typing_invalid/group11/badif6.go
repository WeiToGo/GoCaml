package main

func main(){

if 5{

}else if 5{

}

}

//this program corresponds to the sixth check in symIFSTATE: the condition of an if/else/if statement must be a boolean

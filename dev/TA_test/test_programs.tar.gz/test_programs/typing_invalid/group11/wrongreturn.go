package main

func main() int {

return 3.0

}

//this program corresponds to checks for whether a function returns the wrong type, such as in (GoType.c) symRETURN

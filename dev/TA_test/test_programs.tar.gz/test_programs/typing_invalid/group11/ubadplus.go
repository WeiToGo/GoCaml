package main

func main(){
	x:=+"this is a string"
}

//this invalid program corresponds to checking that the operand of a unary '+' is a number, checked in typeFactor under uplusK

package main

//type num int
var x num

//this invalid program corresponds to checks for whether a type is undefined, such as in symIDIDLIST, symIDIDTYPEEXPLIST, symTYPELINE, symFUNCDEC, 

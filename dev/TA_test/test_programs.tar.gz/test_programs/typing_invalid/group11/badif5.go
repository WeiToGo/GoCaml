package main

func main(){

if x:=5;5{

}else{

}

}

//this program corresponds to the second check in symIFSTATE: the condition of an if/else statement must be a boolean

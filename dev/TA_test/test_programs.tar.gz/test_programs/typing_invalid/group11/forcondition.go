package main

func main(){

for ;3+5;{
	//who cares what goes in here
}


}

//this invalid program corresponds to a type check for whether the condition of a condition-only for loop is a bool, as in symFORLOOP (first and second exit)

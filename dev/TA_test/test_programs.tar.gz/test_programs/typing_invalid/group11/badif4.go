package main

func main(){

if x:=5;5{

}

}

//this program corresponds to the fourth check in symIFSTATE: the condition of an if statement must be a boolean

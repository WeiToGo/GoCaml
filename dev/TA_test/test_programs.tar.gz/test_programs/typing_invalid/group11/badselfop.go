package main

func main(){

x:=3

x+=3.0

}

//this program corresponds to the check that both sides of a 'self-operation' (e.g., +=,-=) are of the same type in symASSIGNMENT

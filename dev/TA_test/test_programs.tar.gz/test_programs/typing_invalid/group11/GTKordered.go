package main

var x bool=(true>5)

//this program corresponds to the check using the comparable function under GTK in symEXP in GoType.c

package main

func main(){

if 5{

}

}

//this program corresponds to the first check in symIFSTATE: the condition of an if statement must be a boolean

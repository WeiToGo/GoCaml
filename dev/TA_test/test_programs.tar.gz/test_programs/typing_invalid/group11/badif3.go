package main

func main(){

if x:=5;5{

}else if y:=5;5{

}

}

//this program corresponds to the third check in symIFSTATE: the condition of an if/else statement must be a boolean

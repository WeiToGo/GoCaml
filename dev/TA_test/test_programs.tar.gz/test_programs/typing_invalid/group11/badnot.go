package main

func main(){
	x:=!5
}

//this invalid program corresponds to checking that the operand of a unary '!' is a bool, checked in typeFactor under notK

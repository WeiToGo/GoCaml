package main

var x bool=(5||7)

//this program corresponds...first exit of symEXP in GoType.c

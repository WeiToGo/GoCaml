package main

var x bool=(true<false)

//this program corresponds...seventh exit of symEXP in GoType.c

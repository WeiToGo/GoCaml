package main

func main(){

print(x)

}

//this invalid program corresponds to checks for whether a variable is undeclared, such as in GoSymbol.c (symVar)

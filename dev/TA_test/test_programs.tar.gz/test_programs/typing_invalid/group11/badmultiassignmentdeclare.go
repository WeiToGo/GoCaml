package main

func main(){

x=5

}

//this corresponds to the second exit condition in symASSIGNEXPLIST where we check that a variable has been declared before assigning anything to it

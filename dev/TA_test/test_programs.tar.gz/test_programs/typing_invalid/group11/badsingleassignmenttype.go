package main

func main(){

var x int;

x="I am totally not an integer"

}

//this failed program corresponds to the first typecheck in symASSIGNEXPLIST (in GoType.c): that both types of an assignment are the same

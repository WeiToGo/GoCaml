package main

var x int
var x float
var x int=5



package main

var x bool=(true>=false)

//this program corresponds...sixth exit of symEXP in GoType.c

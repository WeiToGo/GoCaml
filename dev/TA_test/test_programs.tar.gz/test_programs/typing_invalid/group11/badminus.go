package main

func main(){
	x:=true+"false"
}

//this invalid program corresponds to checking that both operands of a binary '-' are numbers, checked in typeImplementationADDOp under minusK

package main

func main() int {

x:=5

}

//this function corresponds to checks for whether a function has a necessary return type, such as in (GoType.c) symRETURN

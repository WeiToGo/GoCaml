package main

var x bool=(5!="Help! I'm trapped in a literal-making factory!")

//this program corresponds...fourth exit of symEXP

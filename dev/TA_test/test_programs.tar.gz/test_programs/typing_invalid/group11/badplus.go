package main

func main(){
	x:=true+false
}

//this invalid program corresponds to checking that both operands of a binary '+' are numbers or strings, checked in typeImplementationADDOp under plusK

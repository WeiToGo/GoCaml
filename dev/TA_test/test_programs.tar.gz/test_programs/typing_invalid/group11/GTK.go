package main

var x bool=(true>false)

//this program corresponds...fifth exit of symEXP in GoType.c

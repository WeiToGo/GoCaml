package main

func main(){
	x:=3+string
}

//this invalid program corresponds to checking that both operands of a binary '+' have the SAME type, checked in typeImplementationADDOp under plusK

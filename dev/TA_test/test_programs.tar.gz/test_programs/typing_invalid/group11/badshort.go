package main

func main(){

var a int
var b int

a,b:=5,3

}

//this program fails because it is not the case that at least one variable on the left-hand side is undeclared in this scope
//this corresponds to the check under shortK in symSIMPLESTATE

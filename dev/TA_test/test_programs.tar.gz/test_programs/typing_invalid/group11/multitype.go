package main

type num int
type num float

//this invalid program corresponds to checks for whether a type has been defined multiple times in the same scope, such as in (GoType.c) symTYPELINE, 

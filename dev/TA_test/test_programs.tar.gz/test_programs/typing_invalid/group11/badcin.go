package main

func main(){
	x:=3>>3.0
}

//this invalid program corresponds to checking that both operands of a binary '>>' are integers, checked in typeImplementationMulOp under cinK

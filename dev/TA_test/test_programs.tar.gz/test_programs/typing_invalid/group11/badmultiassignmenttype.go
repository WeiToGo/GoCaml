package main

func main(){
var x float
x=5

}

//this corresponds to the third exit condition in symASSIGNEXPLIST where we check that both sides of an assignment are of the same type

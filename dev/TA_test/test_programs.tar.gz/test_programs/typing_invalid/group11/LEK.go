package main

var x bool=(true<=false)

//this program corresponds...eighth exit of symEXP in GoType.c

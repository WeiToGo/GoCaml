package main 

func f() {
	type a int
	print(a(4.5))
}

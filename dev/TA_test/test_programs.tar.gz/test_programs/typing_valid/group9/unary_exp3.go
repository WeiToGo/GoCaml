package main

var x bool = true
var a = !(x)

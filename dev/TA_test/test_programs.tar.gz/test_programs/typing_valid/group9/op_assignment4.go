package main 

func f() {
	var e int 
	e <<= 1
}

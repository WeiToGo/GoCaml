package main 

func short_decl() {
	a := 5.5 
	x := "hello"
	a, b := 0.5, 1 //a was assigned float
}

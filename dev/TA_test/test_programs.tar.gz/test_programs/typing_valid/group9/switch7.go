package main

func switch_stmts() {
	switch true {
		case true: 
			var x = 34
			x =x 
		case false:
			var x = 35
			x = x
		}

}

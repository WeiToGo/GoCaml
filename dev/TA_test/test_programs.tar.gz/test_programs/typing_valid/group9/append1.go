package main 

func f(){
	var s []string
	append(s, "str")
}

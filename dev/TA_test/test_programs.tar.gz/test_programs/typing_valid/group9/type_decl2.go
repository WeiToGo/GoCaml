package main

type x string
var (
	z, y int
)

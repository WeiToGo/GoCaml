package main

func if_stmts() {
	var x int
	if x = 0; x == 0 {
		return
	}
}

package main

func printing(){
	type t4 struct {
		x float64 
	}
	var z t4
	println(z.x)

}

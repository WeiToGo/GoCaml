package main 

func f() {
	var a = `str` + `uyb` 
	a += `er`
}

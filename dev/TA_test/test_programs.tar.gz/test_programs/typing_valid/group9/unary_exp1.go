package main

var a = +('r')

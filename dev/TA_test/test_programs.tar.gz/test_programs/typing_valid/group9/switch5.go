package main

func switch_stmts() {
	var y int = 1
	switch z:=0; y >0 {
	case y < 0: "str1"
	case y > 1: "str2"
	default: "str"
	}


}

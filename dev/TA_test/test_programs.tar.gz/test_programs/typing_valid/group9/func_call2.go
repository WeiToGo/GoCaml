package main 

func f1(a, b,c int) {
	
}

func main() {
	f1(3, 4, 5) 
}

package main 

func f() {
	var a = 9
	a &= 1
}

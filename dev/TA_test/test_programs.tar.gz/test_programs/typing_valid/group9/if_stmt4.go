package main

func if_stmts() {
	var y int = 0
	if false {
		print((4+3)/2)
	} else if y>1 {
		return
	} else {
		return
	}
}

package main 

func f() {
	var a = "str"
	{
		print("srv"+a)
	}
}

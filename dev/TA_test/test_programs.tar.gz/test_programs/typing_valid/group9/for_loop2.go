package main

func for_stmts() { 
	for 5>2 {
		continue	
	}
}

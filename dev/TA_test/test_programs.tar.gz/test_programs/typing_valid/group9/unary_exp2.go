package main

var x struct {
	a, b int
}
var c = +(x.b)

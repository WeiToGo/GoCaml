package main

func for_stmts() { 
	for 34.5 + 4.5; 5< 10; {
		return
	}
}

package main

func f1(a int, b string) {
	return
}

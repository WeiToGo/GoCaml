package main

var y int = 1
func switch_stmts() {
	switch z:=0; {
	case y < 5: "str1"
	case y > 6: "str2"
	default: "str"
	}
}

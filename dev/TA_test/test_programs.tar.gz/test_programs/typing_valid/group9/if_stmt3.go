package main

func if_stmts() {
	var x string
	if x = x; true {
		print(x+"rew")
	} else {
		return
	}
}

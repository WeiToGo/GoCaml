package main

func f0(){
	return
}

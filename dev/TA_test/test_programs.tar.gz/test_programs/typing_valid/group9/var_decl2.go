package main

var x1, x2 rune = 'g', '1'

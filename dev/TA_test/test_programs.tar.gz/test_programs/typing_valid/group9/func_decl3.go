package main

func f2(a int, b int) {
	var c string
}

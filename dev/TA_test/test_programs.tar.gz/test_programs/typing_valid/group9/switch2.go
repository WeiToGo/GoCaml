package main

func switch_stmts() {
	var y int = 1
	switch y {
	case 0: "zero"
	case 1, 3: "odd" 
	}
}

package main 

func f() {
	var a, b = 'e', 'r'
	a %= b
}

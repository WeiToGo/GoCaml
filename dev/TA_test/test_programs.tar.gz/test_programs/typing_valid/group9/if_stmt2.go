package main

func if_stmts() {
	var x = 3.5
	if  x > 3.0 {
		print(x)
	} else {
		print(x+1.3)
	}
}

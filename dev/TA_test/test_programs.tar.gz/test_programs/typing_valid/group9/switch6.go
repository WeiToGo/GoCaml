package main

var y int = 1
func switch_stmts() {
	switch {
	case y < 0: print("string")
	case y > 0: print(4+1)
	default: "zero"
	}
}

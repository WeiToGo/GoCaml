package main

var a = true || 4 >= 3

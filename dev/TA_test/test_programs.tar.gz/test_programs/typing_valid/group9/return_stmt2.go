package main

func foo()rune {
	return ('r')
}

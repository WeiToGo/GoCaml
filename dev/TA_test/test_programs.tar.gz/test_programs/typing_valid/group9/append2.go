package main 

func f(){
	var s []float64
	append(s, 4.5)
}

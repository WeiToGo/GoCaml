package main

func printing(){
	println(6, 3 + 65, 7.5)
}

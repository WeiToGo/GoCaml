package main

var y int = 1
func switch_stmts() {
	switch z:=0; {
	case y < 0: "zero"
	case y > 1: "odd" 
	}
}

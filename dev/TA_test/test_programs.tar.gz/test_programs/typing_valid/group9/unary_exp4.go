package main

var a = ^(5)

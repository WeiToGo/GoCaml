package main 

func f() {
	var a, b = 4, 1
	a &^= b
}

package main

var x, y int 
var (
	z float64
)

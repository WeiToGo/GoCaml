package main

func if_stmts() {
	var x string
	if false {
		return
	} else if x = x; false {
		print(x+"er")
	} else {
		return
	}
}

package main

func f()[4]float64 {
	var x [4]float64 
	return x
}

package main 

func f() {
	var a [3]string 
	a[0] = "hello"
	print(a[0])
}

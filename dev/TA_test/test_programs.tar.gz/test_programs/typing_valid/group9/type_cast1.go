package main 

func f() {
	var a = 6
	float64(a)

}

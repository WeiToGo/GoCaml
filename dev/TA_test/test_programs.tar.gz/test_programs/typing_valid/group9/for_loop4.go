package main

func for_stmts() { 
	var x int
	for ; ; x++ {
		return
	}
}

package main 

func f() {
	var a = 3
	var b = 9
	b /= a
}

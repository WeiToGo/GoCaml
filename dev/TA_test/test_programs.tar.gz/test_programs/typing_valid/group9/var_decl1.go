package main

var a float64 = 45.6

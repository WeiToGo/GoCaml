package main

var a = 'r' + 'r'

package main

var a = 'g' <= 'f' 

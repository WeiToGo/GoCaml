package main

type num int
var e num = num(4)  

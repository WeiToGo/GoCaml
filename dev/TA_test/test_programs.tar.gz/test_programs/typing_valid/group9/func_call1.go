package main

func f5(a int, b int)int {
	return 1
}

func main(){
	f5(5, 3) 
}

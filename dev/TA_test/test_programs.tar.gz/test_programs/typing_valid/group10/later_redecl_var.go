package main


func main() {
	var v float64
	{
		var x float64 = v
		var v int
		println(x)
	}
}

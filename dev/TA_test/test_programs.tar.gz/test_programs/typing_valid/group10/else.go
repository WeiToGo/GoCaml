package main

func main () {
	var x = 3
	if x < 0 {
		println("negative")
	}else if x > 0 {
		println("positive")
	}
}


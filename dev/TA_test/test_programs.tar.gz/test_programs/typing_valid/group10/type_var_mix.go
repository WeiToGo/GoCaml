package main


func main() {
	type v int
	{
		var x v = v(0)
		var v v = v(1)
		if (x!=v) {
	//		println(x,v)
			}
	}
}

//checkCondition...typeIsBool...segfault
//condition->type = 0
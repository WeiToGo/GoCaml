package main


func main() {
	type t float64
	{
		var x t = t(0.25)
		type t int
		println(x)
	}
}

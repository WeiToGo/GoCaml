package a

type a float64

func f() {
	type a string
}


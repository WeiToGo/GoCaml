package main

var a, b, c = 1, a, b

func main() {
}

package main

type foo int

var a foo = foo(1)

func main() {
}

package main

func main() {
	var a = 1
}

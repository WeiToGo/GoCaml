package main

func main() {
	var a, b = 1, 2
}

package main

var a, b = 1, 2.0

func main() {
}

package main

func main() {
	var a, b, c = 1, a, b
}

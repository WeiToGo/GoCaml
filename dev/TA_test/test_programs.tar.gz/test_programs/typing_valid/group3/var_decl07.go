package main

type potato int

func main() {
	var p potato
}

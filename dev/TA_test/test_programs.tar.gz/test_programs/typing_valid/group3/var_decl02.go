package main

func main() {
	var a, b int
}

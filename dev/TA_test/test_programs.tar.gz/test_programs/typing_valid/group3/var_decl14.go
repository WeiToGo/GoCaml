package main

var a, b = 1, 2

func main() {
}

package main

var a = 1 + 2

func main() {
}

package main

var a, b int

func main() {
}

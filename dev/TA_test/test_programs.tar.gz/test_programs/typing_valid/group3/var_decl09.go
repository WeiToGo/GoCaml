package main

type foo int

func main() {
	var a foo = foo(1)
}

package main

var a, b int = 1, 2

func main() {
}

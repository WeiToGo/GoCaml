package main

type potato int

var p potato

func main() {
}

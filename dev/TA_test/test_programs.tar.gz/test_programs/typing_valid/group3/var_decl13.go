package main

var a = 1

func main() {
}

package main

func main() {
	var a, b int = 1, 2
}

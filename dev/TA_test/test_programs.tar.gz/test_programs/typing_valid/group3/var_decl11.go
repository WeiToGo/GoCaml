package main

var a int

func main() {
}

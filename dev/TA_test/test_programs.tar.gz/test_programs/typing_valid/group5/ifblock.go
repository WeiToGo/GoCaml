package main

func main() {
	a := 1
	if a == 1 {
		a := "a"
		println(a)
	} else {
		a := 1.3
		println(a)
	}
}

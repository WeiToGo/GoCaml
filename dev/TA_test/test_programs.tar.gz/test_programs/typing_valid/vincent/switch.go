package main

func main() {
	switch {
	case true: println("true")
	case false: println("false")
	}
}

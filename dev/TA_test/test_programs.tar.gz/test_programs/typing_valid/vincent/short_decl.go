package main

func main() {
	a := 1
	println(a)

	b, c := 2, 3
	println(b, c)

	b, d := 4, 5
	println(b, d)

}

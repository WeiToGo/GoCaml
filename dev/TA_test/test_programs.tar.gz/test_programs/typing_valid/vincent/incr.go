package main

func main() {
	type num int
	var a int
	var b float64
	var c rune
	var d num

	a++
	a--

	b++
	b--

	c++
	c--

	d++
	d--
}

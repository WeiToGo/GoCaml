package main

func main() {
	a, _ := 0, 1
	_, b := 4, 5
	println(a, b)
}

package main

/*
 * Valid example of providing arguments to a function
 */
func test(a, b int) {}

func main() {
	test(1, 2)
}


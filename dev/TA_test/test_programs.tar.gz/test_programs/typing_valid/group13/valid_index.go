package main

/*
 * Example of indexing an array, index must be an int
 */
func main() {
	var a [5]int
	a[1] = 1
}

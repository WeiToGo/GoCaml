package main

// Valid example of multivariable declaration with type inference
func main() {
	var a, b, c = 1, 5.5, "test"
}

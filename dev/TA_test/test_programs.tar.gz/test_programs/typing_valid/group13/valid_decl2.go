package main

/* Valid example where type of variables is specified in the declaration
 * with assignment occuring as well, type of each expression being assigned
 * must match the type specified */
func main() {
	var a, b, c int = 1, 2, 3
}

package main

/* Example of variable declaration with type specified,
 * but no initialization */
func main() {
	var a, b, c [5]int
}
